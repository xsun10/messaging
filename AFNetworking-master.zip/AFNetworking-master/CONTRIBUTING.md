GitHub Issues is for reporting bugs in AFNetworking and discussing features.  Be sure to check our [documentation](http://cocoadocs.org/docsets/AFNetworking), [FAQ](https://github.com/AFNetworking/AFNetworking/wiki/AFNetworking-FAQ) and [past issues](https://github.com/AFNetworking/AFNetworking/issues?state=closed) before opening any new issues.

Please do not post any general usage questions to GitHub Issues, but instead take them to an appropriate forum such as [Stack Overflow](http://stackoverflow.com/questions/tagged/afnetworking).
